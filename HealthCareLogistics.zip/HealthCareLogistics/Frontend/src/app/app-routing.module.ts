import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './health/home.component';
import { RegisterComponent } from './health/register.component';
import { ManagerComponent } from './health/manager.component';
import { TechnicianComponent } from './health/technician.component';
import { CustomerComponent } from './health/customer.component';
import { ManageroperationsComponent } from './health/manageroperations.component';
import { ManagertestComponent } from './health/managertest.component';
import { ManagertechnicianComponent } from './health/managertechnician.component';
import { CustomeroperationsComponent } from './health/customeroperations.component';
import { TechnicianacceptrejectComponent } from './health/technicianacceptreject.component';
import { CustomertestbookingComponent } from './health/customertestbooking.component';
import { CustomerviewtestsComponent } from './health/customerviewtests.component';
import { ManagerviewtechnicianComponent } from './health/managerviewtechnician.component';
import { ManagerdeletetechnicianComponent } from './health/managerdeletetechnician.component';
import { ManagerviewtestsComponent } from './health/managerviewtests.component';
import { ManagerdeletetestsComponent } from './health/managerdeletetests.component';
import { UpdatetestsComponent } from './health/updatetests.component';
import { ManagerupdatetestsComponent } from './health/managerupdatetests.component';
const routes: Routes = [
  {path:'home',component:HomeComponent},
  {path:'register',component:RegisterComponent},
  {path:'manager',component:ManagerComponent},
  {path:'manageroperations',component:ManageroperationsComponent},
  {path:'technician',component:TechnicianComponent},
  {path:'customer',component:CustomerComponent},
  {path:'managertest',component:ManagertestComponent},
  {path:'managertechnician',component:ManagertechnicianComponent},
  {path:'customeroperations',component:CustomeroperationsComponent},
  {path:'customertestbooking',component:CustomertestbookingComponent},
  {path:'customerviewtests',component:CustomerviewtestsComponent},
  {path:'technicianacceptreject',component:TechnicianacceptrejectComponent},
  {path:'technician',component:TechnicianComponent},
  {path:'managerviewtechnician',component:ManagerviewtechnicianComponent},
  {path:'managerviewtests',component:ManagerviewtestsComponent},
  {path:'managerdeletetests',component:ManagerdeletetestsComponent},
  {path:'managerdeletetechnician',component:ManagerdeletetechnicianComponent},
  {path:'updatetests',component:UpdatetestsComponent},
  {path:'managerupdatetests',component:ManagerupdatetestsComponent},
 ];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

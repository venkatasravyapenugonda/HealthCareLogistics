import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-technicianoperations',
  templateUrl: './technicianoperations.component.html',
  styleUrls: ['./technicianoperations.component.css']
})
export class TechnicianoperationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}

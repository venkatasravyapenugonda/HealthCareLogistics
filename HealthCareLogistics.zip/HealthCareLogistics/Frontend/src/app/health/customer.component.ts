import { Component, OnInit, Input } from '@angular/core';
import { HealthService } from '../health.service';
import {  Router } from '@angular/router';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
message:boolean=false;
  mobile:number;
password:any;
email:any;
result:any;
@Input() data1:any=[];
@Input() data10:String="anu";
result1:any=[];
  constructor(private service:HealthService,private router:Router) { }
  //validating the customer credentials using customer mobile no and password.
  check(mobile,password){
    this.service.getMobile(mobile).subscribe(result1=>{
      this.data1=result1;
    this.service.sendData(this.data1);
    this.service.setDetails(this.data1);
    this.service.gettingData("good afternoon");
   
    this.service.currentUser=this.data1.mobileNo;
    this.service.currentUserMailId=this.data1.email;
  });
    
    this.service.getAllRoleDetails(mobile,password).subscribe(data=>{
      this.result=data;
      if(this.result==3)
      {
        this.router.navigate(['/customertestbooking'])
      }
    
      else {
       this.message=true;
      }

    });
  }
   ngOnInit() {
   }

}

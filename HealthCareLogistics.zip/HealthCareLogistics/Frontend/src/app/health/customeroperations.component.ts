import { Component, OnInit } from '@angular/core';
import { HealthService } from '../health.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-customeroperations',
  templateUrl: './customeroperations.component.html',
  styleUrls: ['./customeroperations.component.css']
})
export class CustomeroperationsComponent implements OnInit {
data:any=[];
result:any=[];
data4:any=[];
res:any;
  constructor(private service:HealthService, private router:Router) { }
 
 // For booking the particular technician by the customer
Booking(technicianEmail:String)
{
   return this.service.addBooking(this.service.currentUserMailId,technicianEmail).subscribe((data:number)=>{
    this.res=data;
    if(this.res==1)
    alert("booked successfully");
  });
  
}  
ngOnInit() {
    this.service.getAllTechnician().subscribe(result=>{this.data=result;console.log(this.data)});
     
  }
  
}

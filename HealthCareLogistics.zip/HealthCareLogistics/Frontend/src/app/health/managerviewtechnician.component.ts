import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthService } from '../health.service';

@Component({
  selector: 'app-managerviewtechnician',
  templateUrl: './managerviewtechnician.component.html',
  styleUrls: ['./managerviewtechnician.component.css']
})
export class ManagerviewtechnicianComponent implements OnInit {
  data:any=[];
  result:any=[];
  message:boolean=false;
  constructor(private router:Router,private service:HealthService) { }
//method for adding the new technician
addTechnician(){

  this.router.navigate(['/managertechnician'])
}
//method for deleting the technician
deleteTechnician(mobile:any){
  this.message=true;
  console.log("in delete technician ts file"+mobile);
  let index=this.data.indexOf(mobile);
  this.data.splice(index,1);
  window.location.reload();
    this.service.deleteTechnician(mobile).subscribe();
  
  }
  //method for displaying all the technician details
getAllTechnician()
{
  this.service.getAllTechnician().subscribe(result=>{this.data=result;
    console.log("in manager delete technician"+this.data);
  
})
}
ngOnInit() {
  this.service.getAllTechnician().subscribe(result=>{this.data=result;
    console.log("data"+this.data)});

}
}

package com.cg.healthcarelogistics.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.healthcarelogistics.dao.TestsDao;
import com.cg.healthcarelogistics.dto.Tests;
import com.cg.healthcarelogistics.dto.UserRegistration;

@Service
public class TestsServiceImpl implements TestsService {
@Autowired
TestsDao technicianRoleDao;
	@Override
	public Tests addTest(Tests test) {
		return technicianRoleDao.addTest(test);
	}

	@Override
	public void updateTest(Long testId, Integer price) {
		technicianRoleDao.updateTest(testId, price);
		
	}

	@Override
	public List<Tests> getAllTests() {
		return technicianRoleDao.getAllTests();
	}



	@Override
	public void deleteTest(Long testId) {
		technicianRoleDao.deleteTest(testId);
	}
}
